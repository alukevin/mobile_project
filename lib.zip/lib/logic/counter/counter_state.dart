class CounterState {
  int counterValue;

  CounterState({this.counterValue = 0});
}
